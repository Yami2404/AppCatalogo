let productos = [];
let carrito = JSON.parse(localStorage.getItem("carrito")) || [];

const catalogo = document.getElementById("catalogo");
const buscador = document.getElementById("buscador");
const categoriaFiltro = document.getElementById("categoriaFiltro");
const itemsCarrito = document.getElementById("items-carrito");
const total = document.getElementById("total");
const loader = document.getElementById("loader");

let paginaActual = 0;
const productosInicio = 20;
const productosPorScroll = 8;
let productosFiltrados = [];

// 🔃 Cargar productos desde JSON
fetch('assets/productos.json')
  .then(res => res.json())
  .then(data => {
    productos = data;
    productosFiltrados = productos;
    cargarCategorias();
    cargarMasProductos(productosInicio);
    renderCarrito();
    observer.observe(loader);
  });

// 📦 Cargar productos por lotes
function cargarMasProductos(cantidad = productosPorScroll) {
  const inicio = paginaActual;
  const fin = paginaActual + cantidad;
  const lista = productosFiltrados.slice(inicio, fin);

  lista.forEach(producto => {
    const div = document.createElement("div");
    div.className = "producto";
    div.innerHTML = `
      <img src="${producto.img}" alt="${producto.nombre}">
      <h3>${producto.nombre}</h3>
      <p>$${producto.precio.toFixed(2)}</p>
      <button onclick="agregarAlCarrito(${producto.id})">Agregar</button>
    `;
    catalogo.appendChild(div);
  });

  paginaActual += cantidad;
}

// 👁 Scroll infinito
const observer = new IntersectionObserver((entries) => {
  if (entries[0].isIntersecting) {
    cargarMasProductos();
  }
}, {
  rootMargin: "200px"
});

// ➕ Agregar al carrito
function agregarAlCarrito(id) {
  const producto = productos.find(p => p.id === id);
  carrito.push(producto);
  localStorage.setItem("carrito", JSON.stringify(carrito));
  renderCarrito();
}

// ❌ Eliminar individual
function eliminarDelCarrito(index) {
  const producto = carrito[index];
  carrito.splice(index, 1);
  localStorage.setItem("carrito", JSON.stringify(carrito));
  renderCarrito();
  mostrarMensaje(`🗑️ "${producto.nombre}" eliminado del carrito`);
}

// 🛒 Mostrar carrito
function renderCarrito() {
  itemsCarrito.innerHTML = "";
  let suma = 0;

  carrito.forEach((p, index) => {
    const li = document.createElement("li");
    li.innerHTML = `
      ${p.nombre} - $${p.precio.toFixed(2)}
      <button onclick="eliminarDelCarrito(${index})" style="margin-left:10px; background:#ef4444; color:#fff; border:none; border-radius:5px; padding:3px 8px; cursor:pointer;">❌</button>
    `;
    itemsCarrito.appendChild(li);
    suma += p.precio;
  });

  total.textContent = suma.toFixed(2);
  document.getElementById("carrito-titulo").textContent = `Carrito 🧺 (${carrito.length})`;
}

// 🧹 Vaciar carrito
function vaciarCarrito() {
  carrito = [];
  localStorage.removeItem("carrito");
  renderCarrito();
  mostrarMensaje("🧹 Carrito vaciado");
}

// 🔍 Filtrar productos
function filtrar() {
  const texto = buscador.value.toLowerCase();
  const categoria = categoriaFiltro.value;

  productosFiltrados = productos.filter(p =>
    p.nombre.toLowerCase().includes(texto) &&
    (categoria === "" || p.categoria === categoria)
  );

  paginaActual = 0;
  catalogo.innerHTML = "";
  cargarMasProductos(productosInicio);
}

// 📂 Cargar categorías
function cargarCategorias() {
  const categorias = [...new Set(productos.map(p => p.categoria))];
  categorias.forEach(cat => {
    const opt = document.createElement("option");
    opt.value = cat;
    opt.textContent = cat;
    categoriaFiltro.appendChild(opt);
  });
}

// 🎧 Eventos
buscador.addEventListener("input", filtrar);
categoriaFiltro.addEventListener("change", filtrar);

// ⬆⬇ Toggle carrito (mostrar/ocultar)
const toggleBtn = document.getElementById("toggle-carrito");
const carritoAside = document.getElementById("carrito");
let carritoVisible = true;

toggleBtn.addEventListener("click", () => {
  carritoVisible = !carritoVisible;
  carritoAside.style.height = carritoVisible ? "auto" : "40px";
  carritoAside.querySelectorAll('*:not(#toggle-carrito)').forEach(el => {
    el.style.display = carritoVisible ? "block" : "none";
  });
  toggleBtn.textContent = carritoVisible ? "▼" : "▲";
});

// 💬 Toast centrado
function mostrarMensaje(texto) {
  const toast = document.getElementById("toast");
  toast.textContent = texto;
  toast.classList.add("show");

  setTimeout(() => {
    toast.classList.remove("show");
  }, 2000);
}
